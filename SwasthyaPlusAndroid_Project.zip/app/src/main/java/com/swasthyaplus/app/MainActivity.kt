package com.swasthyaplus.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.TimeUnit

private val Context.dataStore by preferencesDataStore(name = "swasthya_settings")
private val WATER = intPreferencesKey("water_ml")
private val CHECKS = stringPreferencesKey("checks")
private val WEIGHT = stringPreferencesKey("weight")
private val SLEEP = stringPreferencesKey("sleep")
private val LANGUAGE = stringPreferencesKey("language")
private val REMINDERS = booleanPreferencesKey("reminders")
private val PREFILL = booleanPreferencesKey("prefill_done")

private val Forest = Color(0xFF173F35)
private val Mint = Color(0xFFD6E8CF)
private val Cream = Color(0xFFF3F6F1)
private val Blue = Color(0xFF267BAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        lifecycleScope.launch {
            val prefs = dataStore.data.first()
            if (prefs[PREFILL] != true) {
                dataStore.edit {
                    it[WATER] = 0
                    it[WEIGHT] = "70"
                    it[SLEEP] = "8"
                    it[LANGUAGE] = "मराठी"
                    it[REMINDERS] = true
                    it[PREFILL] = true
                }
            }
            setContent { SwasthyaApp(this@MainActivity) }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "swasthya_water", "Water reminders", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Gentle hydration reminders" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

private fun scheduleWaterReminders(context: Context, enabled: Boolean) {
    val manager = WorkManager.getInstance(context)
    manager.cancelUniqueWork("water_reminder")
    if (!enabled) return
    val request = PeriodicWorkRequestBuilder<WaterReminderWorker>(90, TimeUnit.MINUTES)
        .setInitialDelay(90, TimeUnit.MINUTES)
        .build()
    manager.enqueueUniquePeriodicWork(
        "water_reminder", ExistingPeriodicWorkPolicy.UPDATE, request
    )
}

class WaterReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("swasthya_worker", Context.MODE_PRIVATE)
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val notification = NotificationCompat.Builder(applicationContext, "swasthya_water")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Swasthya+ • पाणी पिण्याची वेळ 💧")
                .setContentText("थोडं पाणी प्या. तहान आणि तुमच्या गरजेनुसार प्रमाण ठरवा.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            manager.notify(90, notification)
        }
        return Result.success()
    }
}

@Composable
fun SwasthyaApp(context: Context) {
    val scope = rememberCoroutineScope()
    val prefs by context.dataStore.data.collectAsState(initial = emptyPreferences())
    var tab by remember { mutableStateOf("आजचा दिवस") }
    val english = prefs[LANGUAGE] == "English"
    val water = prefs[WATER] ?: 0
    val weight = prefs[WEIGHT] ?: "70"
    val sleep = prefs[SLEEP] ?: "8"
    val reminders = prefs[REMINDERS] ?: true
    val checked = (prefs[CHECKS] ?: "").split(",").filter { it.isNotBlank() }.toSet()

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        scope.launch {
            context.dataStore.edit { it[REMINDERS] = granted }
            scheduleWaterReminders(context, granted)
        }
    }

    val labels = if (english)
        listOf("Today", "Water", "Skin care", "Diet & weight", "Sleep", "Reports")
    else listOf("आजचा दिवस", "पाणी", "स्किन केअर", "डाएट व वजन", "झोप", "रिपोर्ट")

    val tasks = if (english) listOf(
        "Face wash + moisturizer", "Sunscreen", "Healthy breakfast",
        "Balanced lunch", "Light exercise", "Night skincare", "Prepare for bed"
    ) else listOf(
        "फेस वॉश + मॉइश्चरायझर", "सनस्क्रीन", "पौष्टिक नाश्ता",
        "संतुलित दुपारचे जेवण", "हलका व्यायाम", "रात्रीची स्किन केअर", "झोपेची तयारी"
    )

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest, secondary = Color(0xFF43866B),
            background = Cream, surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Forest).padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🌿  Swasthya+", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            scope.launch {
                                context.dataStore.edit {
                                    it[LANGUAGE] = if (english) "मराठी" else "English"
                                }
                            }
                        }) { Text(if (english) "मराठी" else "English", color = Color.White) }
                    }
                    Text(if (english) "Small habits, better you." else "छोट्या सवयी, उत्तम आरोग्य.",
                        color = Mint, fontSize = 14.sp)
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(if (english) "YOUR DAILY WELLNESS" else "तुझी वैयक्तिक हेल्थ रूटीन",
                                color = Forest, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                SummaryCard("💧", "$water ml", if (english) "Water today" else "आजचे पाणी", Modifier.weight(1f))
                                SummaryCard("✓", "${checked.size}/7", if (english) "Habits done" else "पूर्ण सवयी", Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(if (english) "Age 29 • 155 cm • Fitness goal" else "वय 29 • उंची 155 सेमी • फिटनेस उद्दिष्ट",
                                color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (english) "Your dashboard" else "तुझा डॅशबोर्ड",
                            color = Forest, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        labels.chunked(3).forEach { group ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                group.forEach { label ->
                                    Card(
                                        modifier = Modifier.weight(1f).clickable { tab = label },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (tab == label) Mint else Color.White
                                        ),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Box(Modifier.fillMaxWidth().padding(vertical = 13.dp, horizontal = 4.dp),
                                            contentAlignment = Alignment.Center) {
                                            Text(label, color = Forest, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                                if (group.size < 3) repeat(3 - group.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
                when (tab) {
                    labels[1] -> {
                        item {
                            SectionCard(if (english) "Water tracker 💧" else "पाणी ट्रॅकर 💧") {
                                Text("$water ml", color = Blue, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                                Text(if (english) "Demo target: 2000 ml; adjust to your needs." else "नमुना लक्ष्य 2000 ml; गरजेनुसार बदल.", color = Color.Gray)
                                Spacer(Modifier.height(8.dp))
                                LinearProgressIndicator(progress = { (water / 2000f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { scope.launch { context.dataStore.edit { it[WATER] = (water - 250).coerceAtLeast(0) } } }) { Text("− 250 ml") }
                                    Button(onClick = { scope.launch { context.dataStore.edit { it[WATER] = water + 250 } } }) { Text("+ 250 ml") }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (english) "90-minute reminders" else "दर 90 मिनिटांनी रिमाइंडर", modifier = Modifier.weight(1f))
                                    Switch(checked = reminders, onCheckedChange = { enabled ->
                                        if (enabled && Build.VERSION.SDK_INT >= 33 &&
                                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            scope.launch { context.dataStore.edit { it[REMINDERS] = enabled } }
                                            scheduleWaterReminders(context, enabled)
                                        }
                                    })
                                }
                                Text(if (english) "Android may delay reminders to save battery." else "बॅटरी वाचवण्यासाठी Android रिमाइंडर उशिरा देऊ शकतो.", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                    labels[2] -> {
                        item { SectionCard(if (english) "Skin care checklist" else "स्किन केअर चेकलिस्ट") {
                            tasks.take(2).forEachIndexed { i, task -> TaskRow(task, "skin$i", checked, scope, context) }
                            Text(if (english) "Combination skin: use a gentle cleanser, light moisturizer and broad-spectrum sunscreen." else "मिश्र त्वचा: सौम्य क्लेंझर, हलका मॉइश्चरायझर आणि ब्रॉड-स्पेक्ट्रम सनस्क्रीन वापर.", color = Color.Gray, fontSize = 13.sp)
                        } }
                    }
                    labels[3] -> {
                        item { SectionCard(if (english) "Vegetarian fitness meals" else "शाकाहारी फिटनेस डाएट") {
                            listOf(
                                (if (english) "Breakfast" else "नाश्ता") to (if (english) "Oats, milk/curd, fruit and nuts" else "ओट्स, दूध/दही, फळ आणि सुका मेवा"),
                                (if (english) "Lunch" else "दुपारचे जेवण") to (if (english) "Roti, dal, vegetables and curd" else "पोळी, डाळ, भाजी आणि दही"),
                                (if (english) "Snack" else "स्नॅक") to (if (english) "Fruit, roasted chana or yogurt" else "फळ, भाजलेले चणे किंवा दही"),
                                (if (english) "Dinner" else "रात्रीचे जेवण") to (if (english) "Paneer/tofu, legumes and vegetables" else "पनीर/टोफू, कडधान्ये आणि भाजी")
                            ).forEach { (title, detail) ->
                                Text(title, color = Forest, fontWeight = FontWeight.Bold)
                                Text(detail, color = Color.DarkGray)
                                Spacer(Modifier.height(5.dp))
                            }
                            OutlinedTextField(value = weight, onValueChange = { v -> scope.launch { context.dataStore.edit { it[WEIGHT] = v } } },
                                label = { Text(if (english) "Weight (kg)" else "वजन (किलो)") }, singleLine = true)
                            Text(if (english) "Meal examples only; personalized calorie targets need activity and health details." else "ही जेवणाची उदाहरणे आहेत; वैयक्तिक कॅलरी लक्ष्यांसाठी हालचाल व आरोग्याची माहिती आवश्यक.", color = Color.Gray, fontSize = 12.sp)
                        } }
                    }
                    labels[4] -> {
                        item { SectionCard(if (english) "Sleep tracker 🌙" else "झोप ट्रॅकर 🌙") {
                            Text(if (english) "Sleep goal: $sleep hours" else "झोपेचे लक्ष्य: $sleep तास", color = Forest, fontWeight = FontWeight.Bold)
                            Text(if (english) "Target bedtime: 11:00 PM • Wake-up: 7:00 AM" else "झोप: रात्री 11:00 • उठणे: सकाळी 7:00")
                            Text(if (english) "Aim for a consistent schedule." else "दररोज शक्यतो नियमित वेळ पाळ.", color = Color.Gray)
                        } }
                    }
                    labels[5] -> {
                        item { SectionCard(if (english) "Progress report" else "प्रगती रिपोर्ट 📊") {
                            Text(if (english) "Habit checklist completion" else "सवयींची पूर्तता", color = Forest)
                            Text("${(checked.size * 100 / 7)}%", fontSize = 30.sp, color = Forest, fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(progress = { checked.size / 7f }, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            Text(if (english) "Water logged: $water ml • Current weight: $weight kg" else "नोंदवलेले पाणी: $water ml • सध्याचे वजन: $weight किलो")
                            Text(if (english) "This first version reports current saved values; historical charts are a future enhancement." else "या पहिल्या आवृत्तीत सध्याच्या सेव्ह केलेल्या नोंदी दिसतात; इतिहासाचे चार्ट पुढील टप्प्यात जोडता येतील.", color = Color.Gray, fontSize = 12.sp)
                        } }
                    }
                    else -> {
                        item { SectionCard(if (english) "Today's habits" else "आजच्या सवयी") {
                            tasks.forEachIndexed { i, task -> TaskRow(task, "task$i", checked, scope, context) }
                        } }
                        item { SectionCard(if (english) "Quick water log" else "पाणी नोंदवा") {
                            Text("$water ml", color = Blue, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Button(onClick = { scope.launch { context.dataStore.edit { it[WATER] = water + 250 } } }) { Text("+ 250 ml") }
                        } }
                    }
                }
                item {
                    Text(if (english) "Stored on this phone • Swasthya+ v1.0" else "डेटा या मोबाईलमध्ये सेव्ह होतो • Swasthya+ v1.0",
                        color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(emoji: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Cream)) {
        Column(Modifier.padding(12.dp)) {
            Text(emoji, fontSize = 20.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Forest)
            Text(caption, fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Forest)
            content()
        }
    }
}

@Composable
private fun TaskRow(
    label: String,
    id: String,
    checked: Set<String>,
    scope: kotlinx.coroutines.CoroutineScope,
    context: Context
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = id in checked, onCheckedChange = { value ->
            scope.launch {
                context.dataStore.edit { prefs ->
                    val old = (prefs[CHECKS] ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()
                    if (value) old.add(id) else old.remove(id)
                    prefs[CHECKS] = old.joinToString(",")
                }
            }
        })
        Text(label, color = Color(0xFF29463B))
    }
}
