# Swasthya+ Android प्रोजेक्ट (v1.0)

ही Android Studio मध्ये उघडता येणारी Kotlin + Jetpack Compose प्रोजेक्ट रचना आहे. हा तयार APK नाही; APK तयार करण्यासाठी Android SDK/Gradle असलेल्या संगणकावर build करावा लागेल.

## समाविष्ट
- मराठी / English भाषा बदल
- पाणी नोंद (+/- 250 ml)
- दर 90 मिनिटांनी hydration reminder साठी WorkManager
- Android 13+ notification permission
- स्किन केअर चेकलिस्ट
- शाकाहारी आहाराचे उदाहरण
- वजन नोंद
- झोपेचे वेळापत्रक
- दैनंदिन सवयींचा प्राथमिक रिपोर्ट
- DataStore द्वारे स्थानिक सेटिंग्ज

## Build कसा करायचा
1. Android Studio (JDK 17) स्थापित करा.
2. `SwasthyaPlusAndroid` फोल्डर Android Studio मध्ये उघडा.
3. Gradle sync पूर्ण होऊ द्या.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. APK साधारणपणे `app/build/outputs/apk/debug/app-debug.apk` येथे मिळेल.

## महत्त्वाच्या मर्यादा
- या वातावरणात Android SDK/Gradle build चालवून APK तपासलेला नाही.
- WorkManager periodic कामे बॅटरी व Android धोरणांमुळे वेळेवर अचूक चालतीलच असे नाही; हे दर 90 मिनिटांनी अंदाजे reminder आहे, exact alarm नाही.
- सध्या reminder ची सक्रिय वेळ 7 AM–11 PM अशी मर्यादित नाही; या पुढील आवृत्तीत time-window logic जोडणे आवश्यक आहे.
- रिपोर्ट सध्या सारांश आहेत; ऐतिहासिक चार्ट आणि रोजच्या नोंदींचे स्वतंत्र डेटाबेस पुढे जोडणे आवश्यक आहे.
- वैयक्तिक कॅलरी, पाणी किंवा वैद्यकीय सल्ल्याऐवजी आहारातील उदाहरणे आहेत.
- डेटा क्लाउडवर जात नाही. Android app data clear/uninstall केल्यास नोंदी नष्ट होऊ शकतात.
